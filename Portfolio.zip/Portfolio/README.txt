MARCO EMAD - PORTFOLIO (web app, works on iPhone / iPad / Android / desktop)

WHAT IS IN THIS FOLDER
  index.html                    the portfolio
  assets/                       ALL images (optimized WebP). The only place images live.
  icons/, manifest.webmanifest  make it installable on a phone home screen
  sw.js                         saves everything on the device so it works offline
  portfolio-single-file.html    the same portfolio as ONE file, images embedded (send by WhatsApp/email)
  tools/make_single_file.py     rebuilds the single file after you change something

PUBLISH ONLINE (visitors need nothing to install)
  Upload this whole folder to a static host (Netlify drag-and-drop, GitHub Pages, Vercel).
  The host must use https:// for the offline/install features. Keep the folder structure as is.

VISITORS ON A PHONE
  iPhone/iPad (Safari): Share -> Add to Home Screen.   Android (Chrome): menu -> Install app.
  After the first visit the images and page also open with no internet.

CHANGE OR ADD AN IMAGE (central management)
  1. Replace the file in assets/ keeping the SAME name and .webp format
     (every place that uses it updates automatically).
  2. Open sw.js and change VERSION "v1" to "v2" so visitors' phones refresh.
  3. Optional: run  python3 tools/make_single_file.py  to refresh the single-file version.
  New image: add it to assets/, reference it as assets/name.webp in index.html, and add the same
  path to the FILES list in sw.js.
  Image sizes: logos ~500px wide, photos ~800-1000px wide, WebP quality ~80 keeps them sharp and light.

NOTES
  - The two fonts (Space Grotesk, Inter) load from Google when online and are then cached; offline
    they fall back to the phone's system font. The single-file version behaves the same.
  - The Instagram buttons are links and need internet.
