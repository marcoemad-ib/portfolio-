"""Builds portfolio-single-file.html: ONE file with every image embedded.
Send it by WhatsApp/email/AirDrop; it opens offline on iPhone, Android and desktop with nothing else needed.
Usage:  python3 tools/make_single_file.py      (run from the Portfolio folder; Python 3 only, no installs)"""
import base64, os, re
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
s = open(os.path.join(root, "index.html"), encoding="utf-8").read()
s = re.sub(r"<!--pwa-start-->.*?<!--pwa-end-->\s*", "", s, flags=re.S)
def embed(m):
    p = os.path.join(root, m.group(1))
    return "data:image/webp;base64," + base64.b64encode(open(p, "rb").read()).decode()
s = re.sub(r"(assets/[A-Za-z0-9._-]+\.webp)", embed, s)
out = os.path.join(root, "portfolio-single-file.html")
open(out, "w", encoding="utf-8").write(s)
print("Created", out, round(os.path.getsize(out) / 1024), "KB")
