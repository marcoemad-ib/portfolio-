/* Offline cache. After replacing any image or editing index.html, change VERSION so phones refresh. */
const VERSION = "v1";
const CORE = "portfolio-core-" + VERSION;
const FONTS = "portfolio-fonts";
const FILES = ["./", "index.html", "manifest.webmanifest", "assets/changan.webp", "assets/chery-elite.webp", "assets/chery-warranty.webp", "assets/chery.webp", "assets/clinido.webp", "assets/cs35.webp", "assets/cs75.webp", "assets/deepal.webp", "assets/diamond.webp", "assets/eado.webp", "assets/event-cs75.webp", "assets/event-feather.webp", "assets/event-stage.webp", "assets/fixology.webp", "assets/gbauto.webp", "assets/genesis.webp", "assets/haval.webp", "assets/herafy.webp", "assets/hyundai.webp", "assets/icaur.webp", "assets/ideo.webp", "assets/liauto.webp", "assets/marco.webp", "assets/mazda.webp", "assets/unit.webp", "assets/univ.webp", "icons/apple-touch-icon.png", "icons/icon-192.png", "icons/icon-512.png", "icons/icon-maskable-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CORE).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith("portfolio-core-") && k !== CORE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});
self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin === location.origin) {
    if (req.mode === "navigate") {
      e.respondWith(
        fetch(req).then((r) => { const copy = r.clone(); caches.open(CORE).then((c) => c.put("index.html", copy)); return r; })
          .catch(() => caches.match("index.html"))
      );
      return;
    }
    e.respondWith(caches.match(req, { ignoreSearch: true }).then((hit) => hit || fetch(req).then((r) => { const copy = r.clone(); caches.open(CORE).then((c) => c.put(req, copy)); return r; })));
    return;
  }
  if (url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com") {
    e.respondWith(caches.open(FONTS).then((c) => c.match(req).then((hit) => {
      const net = fetch(req).then((r) => { c.put(req, r.clone()); return r; }).catch(() => hit);
      return hit || net;
    })));
  }
});
